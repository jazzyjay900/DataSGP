package LMS;

public class User {
    protected String name;
    protected String password;
    protected int libraryCardNum;
    
    public User() {
        name = "admin";
        password = "admin";
        libraryCardNum = 1234;
    }
}
