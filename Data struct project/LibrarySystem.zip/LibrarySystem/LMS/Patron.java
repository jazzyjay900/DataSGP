package LMS;

import java.util.ArrayList;

public class Patron extends User {
    private BookStack checkedOutBooks;
    private BookStack holder;
    private ArrayList<Book> borrowedBooks;
    private String salt;
    private String hashedPassword;
    
    // Default constructor
    public Patron() {
        name = "Jane Doe";
        password = "Admin";
        libraryCardNum = 000000;
        checkedOutBooks = new BookStack();
        holder = new BookStack();
        borrowedBooks = new ArrayList<>();
    }
    
    // Primary constructor
    public Patron(String name, String password, int libraryCardNum) {
        this.name = name;
        this.password = password;
        this.libraryCardNum = libraryCardNum;
        checkedOutBooks = new BookStack();
        holder = new BookStack();
        borrowedBooks = new ArrayList<>();
    }
    
    // Constructor for use with PasswordManager
    public Patron(String name, int libraryCardNum, ArrayList<Book> borrowedBooks, String salt, String hashedPassword) {
        this.name = name;
        this.password = null; // Not storing plain password
        this.libraryCardNum = libraryCardNum;
        this.borrowedBooks = borrowedBooks;
        this.salt = salt;
        this.hashedPassword = hashedPassword;
        checkedOutBooks = new BookStack();
        holder = new BookStack();
    }
    
    // Copy constructor
    public Patron(Patron obj) {
        this.name = obj.name;
        this.password = obj.password;
        this.libraryCardNum = obj.libraryCardNum;
        this.checkedOutBooks = new BookStack();
        this.holder = new BookStack();
        this.borrowedBooks = new ArrayList<>();
        this.salt = obj.salt;
        this.hashedPassword = obj.hashedPassword;
    }
    
    // Getters and setters
    public String getName() {
        return name;
    }
    
    public void setName(String name) {
        this.name = name;
    }
    
    public String getPassword() {
        return password;
    }
    
    public void setPassword(String password) {
        this.password = password;
    }
    
    public int getLibaryCardNum() {
        return libraryCardNum;
    }
    
    public void setLibaryCardNum(int libraryCardNum) {
        this.libraryCardNum = libraryCardNum;
    }
    
    public BookStack getCheckedOutBooks() {
        return checkedOutBooks;
    }
    
    public void setCheckedOutBooks(BookStack checkedOutBooks) {
        this.checkedOutBooks = checkedOutBooks;
    }
    
    public String getSalt() {
        return salt;
    }
    
    public void setSalt(String salt) {
        this.salt = salt;
    }
    
    public String getHashedPassword() {
        return hashedPassword;
    }
    
    public void setHashedPassword(String hashedPassword) {
        this.hashedPassword = hashedPassword;
    }
    
    public ArrayList<Book> getBorrowedBooks() {
        return borrowedBooks;
    }
    
    public void setBorrowedBooks(ArrayList<Book> borrowedBooks) {
        this.borrowedBooks = borrowedBooks;
    }
    
    // Methods
    public void checkOutBook(Book book) {
        if(book.getIsavailable()) {
            book.checkOut();
            checkedOutBooks.Push(book);
            borrowedBooks.add(book);
        } else {
            System.out.println(book.getTitle() + " is currently unavailable");
        }
    }
    
    public void Undo() {
        if (checkedOutBooks.getTop() != null) {
            holder.Push(checkedOutBooks.Pop());
            holder.getTop().getdata().checkIn();
        } else {
            System.out.println("No books to undo checkout!");
        }
    }
    
    public void Redo() {
        if (holder.getTop() != null) {
            checkedOutBooks.Push(holder.Pop());
            checkedOutBooks.getTop().getdata().checkOut();
        } else {
            System.out.println("No books to redo checkout!");
        }
    }
    
    public void returnBook() {
        if (checkedOutBooks.getTop() != null) {
            Book returnedBook = checkedOutBooks.Pop();
            returnedBook.checkIn();
            System.out.println(name + " returned " + returnedBook.getTitle());
            
            // Remove from borrowed books list
            borrowedBooks.removeIf(book -> book.getISBN() == returnedBook.getISBN());
        } else {
            System.out.println("No books to return!");
        }
    }
}