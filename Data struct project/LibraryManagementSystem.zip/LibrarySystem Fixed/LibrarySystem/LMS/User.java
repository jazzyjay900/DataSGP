package LMS;
/*Rajay Trowers 2205702
Dijean Sterling 2304879
Jahzeal Simms 2202446
Abigail Bembridge 2305624
Kadedra Mason 2304879*/
public class User {
    protected String name;
    protected String password;
    protected int libraryCardNum;
    
    public User() {
        name = "admin";
        password = "admin";
        libraryCardNum = 1234;
    }
}
